    public interface IAggregateRoot : IEntity
    {
        [SuppressMessage("Microsoft.Performance", "CA1819:PropertiesShouldNotReturnArrays")]
        byte[] RowVersion { get; }
        long VersionId { get; }
    }
