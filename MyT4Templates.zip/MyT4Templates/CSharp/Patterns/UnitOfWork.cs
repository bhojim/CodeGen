    #region Enums

    internal enum OperationType
    {
        Insert,
        Update,
        Delete
    }

    #endregion

    public class UnitOfWork : IUnitOfWork
    {
        #region Fields

        private List<Operation> _operations;

        #endregion

        #region Constructors

        public UnitOfWork()
        {
            this._operations = new List<Operation>();
        }

        #endregion

        #region Operation Class

        private sealed class Operation
        {
            public IEntity Entity { get; set; }
            public DateTime ProcessDate { get; set; }
            public IUnitOfWorkRepository Repository { get; set; }
            public OperationType Type { get; set; }
        }

        #endregion

        #region IUnitOfWork Members

        public void RegisterAdded(IEntity entity, IUnitOfWorkRepository repository)
        {
            _operations.Add(new Operation
            {
                Entity = entity,
                ProcessDate = DateTime.Now,
                Repository = repository,
                Type = OperationType.Insert
            });
        }

        public void RegisterChanged(IEntity entity, IUnitOfWorkRepository repository)
        {
            _operations.Add(new Operation
            {
                Entity = entity,
                ProcessDate = DateTime.Now,
                Repository = repository,
                Type = OperationType.Update
            });
        }

        public void RegisterRemoved(IEntity entity, IUnitOfWorkRepository repository)
        {
            _operations.Add(new Operation
            {
                Entity = entity,
                ProcessDate = DateTime.Now,
                Repository = repository,
                Type = OperationType.Delete
            });
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes", Justification = "'Rethrow'' will rethrow the exception")]
        public void Commit()
        {
            Stack<Operation> completedOperations = new Stack<Operation>(_operations.Count);

            using (var transactionScope = new TransactionScope())
            {
                try
                {
                    foreach (var operation in _operations.OrderBy(o => o.ProcessDate))
                    {
                        PersistOperation(operation);

                        completedOperations.Push(operation);
                    }

                    transactionScope.Complete();
                }
                catch (Exception e)
                {
                    IExceptionContext context = ExceptionHelper.TryPreserveStackTrace(e);

                    foreach (var operation in completedOperations)
                    {
                        RollbackOperation(operation);
                    }

                    context.Rethrow();
                }
            }

            _operations.Clear();
        }

        private static void RollbackOperation(Operation operation)
        {
            switch (operation.Type)
            {
                case OperationType.Insert:
                    operation.Repository.RollbackNewItem(operation.Entity);
                    break;
                case OperationType.Delete:
                    operation.Repository.RollbackDeletedItem(operation.Entity);
                    break;
                case OperationType.Update:
                    operation.Repository.RollbackUpdatedItem(operation.Entity);
                    break;
            }
        }

        private static void PersistOperation(Operation operation)
        {
            switch (operation.Type)
            {
                case OperationType.Insert:
                    operation.Repository.PersistNewItem(operation.Entity);
                    break;
                case OperationType.Delete:
                    operation.Repository.PersistDeletedItem(operation.Entity);
                    break;
                case OperationType.Update:
                    operation.Repository.PersistUpdatedItem(operation.Entity);
                    break;
            }
        }

        #endregion
    }
