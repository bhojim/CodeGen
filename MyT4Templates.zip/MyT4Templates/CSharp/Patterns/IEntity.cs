    public interface IEntity
    {
        int Id { get; }
    }
