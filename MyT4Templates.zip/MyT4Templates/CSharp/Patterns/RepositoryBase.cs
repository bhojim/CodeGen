    public abstract class RepositoryBase<T> : IRepository<T>, IUnitOfWorkRepository where T : IAggregateRoot
    {
        #region Fields

        private IUnitOfWork _unitOfWork;

        #endregion

        #region Constructors

        protected RepositoryBase() : this(null)
        {
        }

        protected RepositoryBase(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        #endregion

        #region IRepository<T> Members

        public abstract T FindById(int id);

        public void Add(T item)
        {
            AssertUnitOfWorkIsNotNull();

            _unitOfWork.RegisterAdded(item, this);
        }

        public void Remove(T item)
        {
            AssertUnitOfWorkIsNotNull();

            _unitOfWork.RegisterRemoved(item, this);
        }

        public void RegisterAdded(IEntity item)
        {
            AssertUnitOfWorkIsNotNull();

            _unitOfWork.RegisterAdded(item, this);
        }

        public void RegisterChanged(IEntity item)
        {
            AssertUnitOfWorkIsNotNull();

            _unitOfWork.RegisterChanged(item, this);
        }

        public void RegisterRemoved(IEntity item)
        {
            AssertUnitOfWorkIsNotNull();

            _unitOfWork.RegisterRemoved(item, this);
        }

        #endregion

        #region IUnitOfWorkRepository Members

        public virtual void PersistNewItem(IEntity item)
        {
            PersistNewItem((T)item);
        }

        public virtual void PersistUpdatedItem(IEntity item)
        {
            PersistUpdatedItem((T)item);
        }

        public virtual void PersistDeletedItem(IEntity item)
        {
            PersistDeletedItem((T)item);
        }

        public virtual void RollbackNewItem(IEntity item) { }

        public virtual void RollbackUpdatedItem(IEntity item) { }

        public virtual void RollbackDeletedItem(IEntity item) { }

        #endregion

        #region Abstract Methods

        protected abstract void PersistNewItem(T item);
        protected abstract void PersistUpdatedItem(T item);
        protected abstract void PersistDeletedItem(T item);

        #endregion

        #region Protected Methods

        protected void ProcessInsertedItem(IEntity item, int id)
        {
            SetIdField(item, id);
        }

        [SuppressMessage("Microsoft.Design", "CA1011:ConsiderPassingBaseTypesAsParameters")]
        protected void ProcessInsertedItem(IAggregateRoot item, int id, long versionId)
        {
            SetIdField(item, id);
            SetVersionIdField(item, versionId);
        }

        [SuppressMessage("Microsoft.Design", "CA1011:ConsiderPassingBaseTypesAsParameters")]
        protected void ProcessUpdatedItem(IAggregateRoot item, long versionId)
        {
            SetVersionIdField(item, versionId);
        }

        protected static FieldInfo GetField(IEntity item, Type declaringType, string fieldName)
        {
            FieldInfo result = null;
            Type t = item.GetType();

            while (t != null)
            {
                if (t == declaringType)
                {
                    result = t.GetField(fieldName, BindingFlags.Instance | BindingFlags.NonPublic);
                    break;
                }
                else
                {
                    t = t.BaseType;
                }
            }

            return result;
        }

        #endregion

        #region Private Methods

        private void AssertUnitOfWorkIsNotNull()
        {
            if (_unitOfWork == null)
            {
                throw new InvalidOperationException("The unit of work has not been initialized.");
            }
        }

        private static void SetIdField(IEntity item, int id)
        {
            FieldInfo idField = GetField(item, typeof(EntityBase), "_id");
            idField.SetValue(item, id);
        }

        private static void SetVersionIdField(IAggregateRoot item, long versionId)
        {
            FieldInfo versionIdField = GetField(item, typeof(AggregateRootBase), "_versionId");
            versionIdField.SetValue(item, versionId);
        }

        #endregion
    }

