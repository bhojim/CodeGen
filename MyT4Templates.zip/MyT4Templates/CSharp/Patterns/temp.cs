

// Pass the UnitOfWork to the Repository
 
	IUnitOfWork unitOfWork = new UnitOfWork();
