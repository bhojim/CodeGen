	
    public interface IUnitOfWork
    {
        void Commit();
        void CommitWitDefaultTransaction();
        void RegisterAdded(IEntity entity, IUnitOfWorkRepository repository);
        void RegisterChanged(IEntity entity, IUnitOfWorkRepository repository);
        void RegisterRemoved(IEntity entity, IUnitOfWorkRepository repository);
    }
