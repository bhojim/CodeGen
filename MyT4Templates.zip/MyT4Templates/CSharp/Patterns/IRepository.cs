    public interface IRepository<T> where T : IAggregateRoot
    {
        T FindById(int id);
        void Add(T item);
        void Remove(T item);
        void RegisterAdded(IEntity item);
        void RegisterChanged(IEntity item);
        void RegisterRemoved(IEntity item);
    }
