    public interface IUnitOfWorkRepository
    {
        void PersistNewItem(IEntity item);
        void PersistUpdatedItem(IEntity item);
        void PersistDeletedItem(IEntity item);

        void RollbackNewItem(IEntity item);
        void RollbackUpdatedItem(IEntity item);
        void RollbackDeletedItem(IEntity item);
    }

