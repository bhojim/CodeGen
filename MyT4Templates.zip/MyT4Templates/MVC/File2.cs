        [HttpGet]
        public JsonResult GetDealers(int fiscalYear, bool includeAll)
        {
            IEnumerable<Model.Dealers.DealerSummary> dealers = Ofa.Applications.Ace.Application.DealerService.GetDealers(fiscalYear);
            IEnumerable<System.Web.Mvc.SelectListItem> dealerList = new SelectList(dealers, "Id", "Name");
            List<System.Web.Mvc.SelectListItem> items = new List<SelectListItem>();
            if (includeAll)
            {
                items.Add(new SelectListItem { Text = "All", Value = "0" });
            }
            items.AddRange(dealerList);
            return Json(items.ToList(), JsonRequestBehavior.AllowGet);
        }

