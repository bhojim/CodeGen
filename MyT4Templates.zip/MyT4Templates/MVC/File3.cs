namespace Ofa.Applications.Ace.Model.Dealers
{
    [Serializable]
    public class DealerSummary
    {
        #region Fields

        private int _id;
        private string _code;
        private string _name;

        #endregion

        #region Constructors

        private DealerSummary(int id, string code, string name)
        { 
            _id = id;
            _code = code;
            _name = name;
        }

        #endregion

        #region Factory Methods

        public static DealerSummary LoadFromPersistence(int id, string code, string name)
        {
            return new DealerSummary(id, code, name);
        }

        #endregion

        #region Properties

        public int Id { get { return _id; } }
        public string Code { get { return _code; } }
        public string Name { get { return _name; } }

        #endregion
    }
}

